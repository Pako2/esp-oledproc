Kodi (XBMC) LCDproc Python addon
=================================

Copyright (C) 2012-2018 Team Kodi, Daniel 'herrnst' Scheller
Based on initial work (C) 2012 Memphiz/Team Kodi (formerly Team XBMC)

LCDproc support for Kodi implemented in Python, direct drop-in replacement for
the LCD support that was present in prior versions of XBMC and it's core.

See https://github.com/herrnst/script.xbmc.lcdproc/wiki for details and usage
information.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

See LICENSE.txt for more information.
